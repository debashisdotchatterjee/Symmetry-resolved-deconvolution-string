# Interpretation rules

- Genuine real data: GIANT 2014 height GWAS signed regression coefficients and reported SEs.
- Artificial intervention: randomized suppression of effect-allele sign with known probabilities.
- Do NOT describe controlled sign masking as natural loss of effect-allele labels.
- Aligned GWAS summary estimates are a NOISY REFERENCE, never true latent effects.
- Hash-based thinning is **not linkage-disequilibrium pruning**; independence may fail.
- Allele convention fixes an arbitrary orientation; sign changes are not genetic effect changes.
- All confidence displays based on repeated masking measure masking randomness only.
- Fourier inversions are unconstrained and can be negative; no hidden positivity clipping.
- Cutoffs use a prespecified upper-risk proxy with a non-estimated Sobolev constant L.
- No real-data results are claimed if source download or parsing failed.
- If the fully balanced channel is used, only the invariant density is identifiable.
